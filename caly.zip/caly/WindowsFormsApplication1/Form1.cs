﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        Double v= 0;
        String opr = "";
        bool opr_pressed = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (opr_pressed))
            {

                textBox1.Clear();
            }
            
            
                
            Button b = (Button)sender;
            if (b.Text == ".")
            {
                if (!textBox1.Text.Contains("."))
                {

                    textBox1.Text = textBox1.Text + b.Text;
                }
            }

            else

                textBox1.Text = textBox1.Text + b.Text;
            opr_pressed = false;
                
            
    }
            
            
            
            //label1.Text = result + " " + opr;
            

            

        

        private void operator_click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (v != 0)
            {
                button10.PerformClick();

                opr = b.Text;
                
                label1.Text = v + " " + opr;
                opr_pressed = true;
            }
            else
            {

                opr = b.Text;
                v = Double.Parse(textBox1.Text);
                label1.Text = v + " " + opr;
                opr_pressed = true;
            }

        }

        private void ce_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
        }

        private void c_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            v = 0;
        }

        private void e_Click(object sender, EventArgs e)
        {


            switch (opr)
            {
                case "+":
                    textBox1.Text = (v + Double.Parse(textBox1.Text)).ToString();
                    break;
                case "-":
                    textBox1.Text = (v - Double.Parse(textBox1.Text)).ToString();
                    break;
                    
                case "/":
                    textBox1.Text = (v / Double.Parse(textBox1.Text)).ToString();
                    break;
                case "*":
                    textBox1.Text = (v * Double.Parse(textBox1.Text)).ToString();
                    break;
                default:
                    break;
            }
            v = Double.Parse(textBox1.Text);
            label1.Text = " ";

        }
    }
}
